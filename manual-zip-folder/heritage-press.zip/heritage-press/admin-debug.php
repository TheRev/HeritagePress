<?php
/**
 * Add some debug output to admin footer to help troubleshoot menu issues
 */

add_action('admin_footer', function() {
    echo '<div style="margin: 2em; padding: 1em; border: 1px solid #ccc; background: #fff;">';
    echo '<h3>Heritage Press Debug Info:</h3>';
    
    // Check if main Plugin class exists and is instantiated
    if (class_exists('HeritagePress\Core\Plugin')) {
        echo '<p>✅ Main Plugin class exists</p>';
        
        // Try to get plugin instance
        $plugin = HeritagePress\Core\Plugin::get_instance();
        if ($plugin) {
            echo '<p>✅ Plugin instance exists</p>';
        } else {
            echo '<p>❌ Could not get plugin instance</p>';
        }
    } else {
        echo '<p>❌ Main Plugin class not found</p>';
    }
    
    // Check Evidence_Admin registration
    if (class_exists('HeritagePress\Admin\Evidence_Admin')) {
        echo '<p>✅ Evidence_Admin class exists</p>';
    } else {
        echo '<p>❌ Evidence_Admin class not found</p>';
    }
    
    // Check WordPress hooks
    global $wp_filter;
    if (isset($wp_filter['admin_menu'])) {
        echo '<p>✅ admin_menu hooks exist. Priorities:</p><ul>';
        foreach ($wp_filter['admin_menu']->callbacks as $priority => $callbacks) {
            foreach ($callbacks as $callback) {
                if (is_array($callback['function'])) {
                    $class = is_object($callback['function'][0]) ? get_class($callback['function'][0]) : $callback['function'][0];
                    $method = $callback['function'][1];
                    echo "<li>Priority $priority: $class::$method</li>";
                } else {
                    echo "<li>Priority $priority: " . (is_callable($callback['function']) ? 'Anonymous function' : 'Unknown') . "</li>";
                }
            }
        }
        echo '</ul>';
    } else {
        echo '<p>❌ No admin_menu hooks found</p>';
    }
    
    // Check user capabilities
    if (current_user_can('manage_options')) {
        echo '<p>✅ Current user has manage_options capability</p>';
    } else {
        echo '<p>❌ Current user lacks manage_options capability</p>';
    }
    
    echo '</div>';
});
