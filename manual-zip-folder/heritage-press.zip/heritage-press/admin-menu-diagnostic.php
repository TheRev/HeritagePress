<?php
/**
 * Heritage Press Admin Menu Diagnostic
 * Place this in wp-content/plugins/heritage-press/ and access via browser
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Heritage Press Admin Menu Diagnostic</h1>";
echo "<pre>";

// Check if WordPress is loaded
if (!defined('ABSPATH')) {
    echo "❌ WordPress not loaded. Place this file in wp-content/plugins/heritage-press/ and access via browser.\n";
    exit;
}

echo "✅ WordPress loaded\n";
echo "WordPress Version: " . get_bloginfo('version') . "\n";
echo "Plugin Directory: " . plugin_dir_path(__FILE__) . "\n\n";

// Check if Heritage Press plugin is active
if (!class_exists('HeritagePress\Core\Plugin')) {
    echo "❌ HeritagePress\Core\Plugin class not found\n";
    echo "Checking autoloader...\n";
    
    $autoloader_path = plugin_dir_path(__FILE__) . 'includes/class-autoloader.php';
    if (file_exists($autoloader_path)) {
        echo "✅ Autoloader file exists\n";
        require_once $autoloader_path;
        
        if (class_exists('HeritagePress\Core\Autoloader')) {
            echo "✅ Autoloader class loaded\n";
            HeritagePress\Core\Autoloader::register();
            echo "✅ Autoloader registered\n";
            
            if (class_exists('HeritagePress\Core\Plugin')) {
                echo "✅ Plugin class now available\n";
            } else {
                echo "❌ Plugin class still not available after autoloader\n";
            }
        } else {
            echo "❌ Autoloader class not found\n";
        }
    } else {
        echo "❌ Autoloader file not found at: $autoloader_path\n";
    }
} else {
    echo "✅ HeritagePress\Core\Plugin class is available\n";
}

// Check if Plugin instance exists
try {
    $plugin_instance = HeritagePress\Core\Plugin::get_instance();
    echo "✅ Plugin instance created successfully\n";
} catch (Exception $e) {
    echo "❌ Error creating plugin instance: " . $e->getMessage() . "\n";
}

// Check Evidence Admin class
echo "\n=== Evidence Admin Check ===\n";
if (class_exists('HeritagePress\Admin\Evidence_Admin')) {
    echo "✅ Evidence_Admin class available\n";
    
    try {
        $evidence_admin = new HeritagePress\Admin\Evidence_Admin();
        echo "✅ Evidence_Admin instance created\n";
        
        if (method_exists($evidence_admin, 'init')) {
            echo "✅ Evidence_Admin has init() method\n";
        } else {
            echo "❌ Evidence_Admin missing init() method\n";
        }
        
        if (method_exists($evidence_admin, 'add_admin_menus')) {
            echo "✅ Evidence_Admin has add_admin_menus() method\n";
        } else {
            echo "❌ Evidence_Admin missing add_admin_menus() method\n";
        }
    } catch (Exception $e) {
        echo "❌ Error creating Evidence_Admin: " . $e->getMessage() . "\n";
    }
} else {
    echo "❌ Evidence_Admin class not found\n";
}

// Check WordPress hooks
echo "\n=== WordPress Hooks Check ===\n";
global $wp_filter;

// Check if admin_menu hooks are registered
if (isset($wp_filter['admin_menu'])) {
    echo "✅ admin_menu hooks registered:\n";
    foreach ($wp_filter['admin_menu']->callbacks as $priority => $callbacks) {
        foreach ($callbacks as $callback) {
            if (is_array($callback['function'])) {
                $class = is_object($callback['function'][0]) ? get_class($callback['function'][0]) : $callback['function'][0];
                $method = $callback['function'][1];
                echo "  - Priority $priority: $class::$method\n";
            } else {
                echo "  - Priority $priority: " . $callback['function'] . "\n";
            }
        }
    }
} else {
    echo "❌ No admin_menu hooks registered\n";
}

// Check if we're in admin area
echo "\n=== Admin Area Check ===\n";
if (is_admin()) {
    echo "✅ Currently in WordPress admin area\n";
    
    // Check current screen
    $screen = get_current_screen();
    if ($screen) {
        echo "Current screen ID: " . $screen->id . "\n";
        echo "Current screen base: " . $screen->base . "\n";
    }
} else {
    echo "❌ Not in WordPress admin area\n";
}

// Manual hook registration test
echo "\n=== Manual Hook Test ===\n";
if (function_exists('add_action')) {
    echo "✅ add_action function available\n";
    
    // Try to register a test menu
    add_action('admin_menu', function() {
        echo "🔧 Test admin menu hook executed\n";
        
        add_menu_page(
            'Test Heritage Menu',
            'Test Heritage',
            'manage_options',
            'test-heritage',
            function() { echo 'Test page'; },
            'dashicons-admin-tools',
            99
        );
    });
    
    echo "✅ Test admin menu hook registered\n";
} else {
    echo "❌ add_action function not available\n";
}

// Check current user capabilities
echo "\n=== User Capabilities Check ===\n";
$current_user = wp_get_current_user();
echo "Current user: " . $current_user->user_login . "\n";
echo "User ID: " . $current_user->ID . "\n";

$required_caps = ['manage_options', 'edit_posts'];
foreach ($required_caps as $cap) {
    if (current_user_can($cap)) {
        echo "✅ User has '$cap' capability\n";
    } else {
        echo "❌ User missing '$cap' capability\n";
    }
}

echo "\n=== Recommendations ===\n";
echo "1. Check WordPress error log for any PHP errors\n";
echo "2. Ensure you're logged in as an administrator\n";
echo "3. Check if any other plugins are conflicting\n";
echo "4. Try deactivating and reactivating the Heritage Press plugin\n";

echo "</pre>";
?>
